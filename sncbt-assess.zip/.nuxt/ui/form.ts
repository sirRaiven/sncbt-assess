export default {
  "base": ""
}