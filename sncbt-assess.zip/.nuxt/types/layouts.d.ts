import type { ComputedRef, MaybeRef } from 'vue'

type ComponentProps<T> = T extends new(...args: any) => { $props: infer P } ? NonNullable<P>
  : T extends (props: infer P, ...args: any) => any ? P
  : {}

declare module 'nuxt/app' {
  interface NuxtLayouts {
    admin: ComponentProps<typeof import("C:/Users/raive/Desktop/sncbt-assess/app/layouts/admin.vue").default>
    auth: ComponentProps<typeof import("C:/Users/raive/Desktop/sncbt-assess/app/layouts/auth.vue").default>
    exam: ComponentProps<typeof import("C:/Users/raive/Desktop/sncbt-assess/app/layouts/exam.vue").default>
    instructor: ComponentProps<typeof import("C:/Users/raive/Desktop/sncbt-assess/app/layouts/instructor.vue").default>
    student: ComponentProps<typeof import("C:/Users/raive/Desktop/sncbt-assess/app/layouts/student.vue").default>
  }
  export type LayoutKey = keyof NuxtLayouts extends never ? string : keyof NuxtLayouts
  interface PageMeta {
    layout?: MaybeRef<LayoutKey | false> | ComputedRef<LayoutKey | false> | {
      [K in LayoutKey]: {
        name?: MaybeRef<K | false> | ComputedRef<K | false>
        props?: NuxtLayouts[K]
      }
    }[LayoutKey]
  }
}