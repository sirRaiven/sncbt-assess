<template>
  <DashboardShell role="student">
    <slot />
  </DashboardShell>
</template>
