<script setup lang="ts">
withDefaults(defineProps<{
    title: string;
    description: string;
    eyebrow?: string;
    actionLabel?: string;
    actionTo?: string;
    actionIcon?: string;
}>(), {
    eyebrow: "Workspace",
    actionLabel: "",
    actionTo: "",
    actionIcon: "i-lucide-plus",
});
const rows = [
    {
        name: "Mobile Development Prelim Examination",
        detail: "IT216 · BSIT 2A",
        status: "Published",
        value: "50 questions",
    },
    {
        name: "Flutter Project Structure Quiz",
        detail: "IT216 · BSIT 2A",
        status: "Draft",
        value: "20 questions",
    },
    {
        name: "Platform Technologies Review",
        detail: "IT113 · BSIT 1A",
        status: "Completed",
        value: "44 participants",
    },
];
</script>

<template>
  <div class="page-stack">
    <PageHeader
      :eyebrow="eyebrow"
      :title="title"
      :description="description"
    >
      <template
        v-if="actionLabel"
        #actions
      >
        <UButton
          :to="actionTo || undefined"
          :icon="actionIcon"
        >
          {{ actionLabel }}
        </UButton>
      </template>
    </PageHeader>
    <section class="grid gap-4 sm:grid-cols-3">
      <StatCard
        label="Total records"
        value="18"
        icon="i-lucide-layers-3"
        tone="primary"
       />
      <StatCard
        label="Active"
        value="12"
        icon="i-lucide-circle-check-big"
        tone="success"
       />
      <StatCard
        label="Needs attention"
        value="3"
        icon="i-lucide-clock-3"
        tone="warning"
       />
    </section>
    <UCard>
      <div class="grid gap-3 lg:grid-cols-[1fr_220px]">
        <UInput
          icon="i-lucide-search"
          placeholder="Search records"
          class="w-full"
         />
        <USelect
          model-value="All statuses"
          :items="[
            'All statuses',
            'Active',
            'Pending',
            'Draft',
            'Completed',
          ]"
          class="w-full"
         />
      </div>
    </UCard>
    <div class="table-shell table-scroll">
      <table class="app-table">
        <thead>
          <tr>
            <th>
              Name
            </th>
            <th>
              Details
            </th>
            <th>
              Summary
            </th>
            <th>
              Status
            </th>
            <th>
              Action
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in rows"
            :key="row.name"
          >
            <td class="font-semibold text-highlighted">
              {{ row.name }}
            </td>
            <td>
              {{ row.detail }}
            </td>
            <td>
              {{ row.value }}
            </td>
            <td>
              <StatusPill :status="row.status" />
            </td>
            <td>
              <UButton
                color="neutral"
                variant="ghost"
                icon="i-lucide-arrow-up-right"
                aria-label="Open record"
               />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
