<script setup lang="ts">
definePageMeta({
  layout:
    "instructor",
});

useSeoMeta({
  title:
    "My Profile",
});
</script>

<template>
  <PortalProfilePage role="instructor" />
</template>
