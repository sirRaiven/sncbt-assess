<script setup lang="ts">
definePageMeta({
    layout: "exam",
});
const index = ref(0);
const selected = ref<number | null>(null);
const q = [
    {
        text: "Which framework is used to build the sample mobile applications in this course?",
        options: [
            "Laravel",
            "Flutter",
            "Django",
            "Spring Boot",
        ],
    },
    {
        text: "Which file contains Flutter package dependencies?",
        options: [
            "main.html",
            "package.json",
            "pubspec.yaml",
            "settings.xml",
        ],
    },
];
const current = computed(() => {
    return q[index.value] ?? q[0]!;
});
function next(): void {
    if (index.value < q.length - 1) {
        index.value += 1;
        selected.value = null;
        return;
    }
    navigateTo("/student/results/demo");
}
</script>

<template>
  <UContainer class="py-8">
    <div class="mx-auto max-w-5xl">
      <div class="mb-5 flex justify-between">
        <div>
          <p class="text-xs font-bold uppercase tracking-[.16em] text-primary">
            Mobile Development Prelim Examination
          </p>
          <p class="mt-1 text-sm text-muted">
            Question {{ index+1 }} of 50
          </p>
        </div>
        <div class="flex gap-2">
          <UBadge
            color="success"
            variant="soft"
          >
            Connected
          </UBadge>
          <UBadge
            color="warning"
            variant="soft"
          >
            00:30
          </UBadge>
        </div>
      </div>
      <UProgress
        :model-value="(index+1)*2"
        class="mb-6"
       />
      <div class="grid gap-6 xl:grid-cols-[1fr_260px]">
        <UCard>
          <p class="text-sm font-bold text-primary">
            Multiple Choice · 1 point
          </p>
          <h1 class="mt-5 text-3xl font-black text-highlighted">
            {{ current.text }}
          </h1>
          <div class="mt-8 grid gap-3 sm:grid-cols-2">
            <button
              v-for="(x,i) in current.options"
              :key="x"
              class="rounded-xl border p-5 text-left font-semibold"
              :class="selected===i?'border-primary bg-primary/5 ring-3 ring-primary/10':'border-default'"
              @click="selected=i"
            >
              <span
                class="mr-3 inline-flex size-8 items-center justify-center rounded-xl bg-elevated"
              >
                {{ String.fromCharCode(65+i) }}
              </span>
              {{ x }}
            </button>
          </div>
          <div class="mt-8 flex justify-end">
            <UButton
              :disabled="selected===null"
              @click="next"
            >
              Save and Continue
            </UButton>
          </div>
        </UCard>
        <UCard>
          <template #header>
            <h2 class="font-bold">
              Your progress
            </h2>
          </template>
          <div class="grid grid-cols-5 gap-2">
            <span
              v-for="n in 15"
              :key="n"
              class="flex aspect-square items-center justify-center rounded-lg text-xs font-bold"
              :class="n===index+1?'bg-primary text-white':n<=index?'bg-success/10 text-success':'bg-elevated text-muted'"
            >
              {{ n }}
            </span>
          </div>
          <UAlert
            class="mt-5"
            color="warning"
            variant="soft"
            title="Stay on this page"
            description="The production version will record disconnections and tab visibility changes."
           />
        </UCard>
      </div>
    </div>
  </UContainer>
</template>
